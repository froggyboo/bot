module.exports = {
  guildRoleMap: {
    '258167954913361930': {
      account: '606324811068735489',
      server: '606262166672113675'
    }
  }
};
